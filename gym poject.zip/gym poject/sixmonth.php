<!DOCTYPE html>

<head>
    <style>
        * {
            background-color: #ffffff;
        }
        
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 120vh;
            margin: 0;
        }
        
        form {
            background: #ffffff;
            padding: 20px;
            border-radius: 10px;
            max-width: 400px;
            box-shadow: 0px 0px 10px rgb(138, 90, 2);
            width: 100%;
        }
        
        fieldset {
            border: none;
        }
        
        h2 {
            margin-bottom: 30px;
            text-align: center;
            color: #333;
        }
        
        i {
            font-style: normal;
            font-weight: bold;
            color: #555;
            font-size: 15px;
        }
        
        input {
            border: 0.5px solid;
        }
        
        input:focus {
            border: 5px solid orangered;
            outline: 1px solid orangered;
        }
        
        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 8px;
            margin: 2px 0 10px 0;
            border: 1px solid rgb(222, 216, 216);
            border-radius: 5px;
            font-size: 14px;
        }
        
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }
        
        input[type="submit"] {
            background: #ee7715;
            color: white;
        }
        
        input[type="submit"]:hover {
            background: #ee7715;
        }
    </style>
    <script>
        

function data()
{   
     let name=document.getElementById("name").value;
     let city=document.getElementById("city").value;
     let letters=/^[a-z A-Z]*$/;
     let mobile=document.getElementById("mobile").value;

    if(name==""||city==""||mobile=="")
    {
        alert("plz all value are fullfill");
        return false;
    }
   else if(!name.match(letters))
    {
        alert("enter only character");
        return false;
    }
    else if(!city.match(letters))
    {
        alert("enter only character");
        return false;
    }
    else if(mobile.length<10||mobile.length>10)
    {
        alert("enter 10 digit number");
        return false;
    }
   
    else if(isNaN(mobile))
    {
       alert("enter only number");
       return false;
    }
    
    else
    {
         true;
    }
  }
</script>


</head>

<body>
<form onsubmit="return data()" action="sixdata.php" method="post">

    <fieldset>
        <h2>Enter Your Detail's</h2>
        <i>USER NAME: </i>
        <input type="text" id="name" placeholder="enter full name" name="name"><br>
        <i> CITY NAME:</i><br>
        <input type="text" id="city" placeholder="enter city" name="city"><br>
        <i>MOBILE NO:</i>
        <input type="text" id="mobile" name="mobile">
        <input type="submit" value="SUBMIT" id="submit"> <br><br>

    </fieldset>
</form>
</body>

</html>

