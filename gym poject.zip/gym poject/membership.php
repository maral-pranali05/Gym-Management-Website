<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        h1{
    text-align: center;
}
table
{
    margin-left: 50px;
    
}


th
{
    height: 70px;
    background: #ee7715;
    width: 400px;
}
td
{
    height: 70px;
}
button
{
    background: orange;
    height: 50px;
    border-radius: 50px;
    width: 150px;
    margin-left: 150px;
    

}
a
{
    color: black;
    text-decoration: none;
}
h2
{
    text-align: center;
    color:black;
}
    </style>
</head>
<body>
    <h1>ENROLL MEMBERSHIP </h1>
    <table border="2">
        <tr>
            <th><h1>DURATION</h1></th>
            <th><h1>AMOUNT</h1></th>
            <th><h1>JOIN MEMBERSHIP</h1></th>
        </tr>
        <tr>
            <td><h2>1 month</h2> </td>
            <td><h2>₹599</h2></td>
            <td><button onclick="window.location.href='onemonth.php';"><a href="onemonth.php">BUY NOW</a></button> </td></button></td>
        </tr>
        <tr>
            <td><h2>3 month's</h2> </td>
            <td><h2>₹1499</h2></td>
            <td><button onclick="window.location.href='threemonth.php';"><a href="threemonth.php">BUY NOW</a></button> </td></button></td>
        </tr>
        <tr>
            <td><h2>6 month's</h2> </td>
            <td><h2>₹2199</h2></td>
            <td><button onclick="window.location.href='sixmonth.php';"><a href="sixmonth.php">BUY NOW</a></button> </td></button></td>
        </tr>
        <tr>
            <td><h2>1 year</h2> </td>
            <td><h2>₹2999</h2></td>
            <td><button onclick="window.location.href='year.php';"><a href="year.php">BUY NOW</a></button> </td></button></td>
        </tr>
    </table>
</table>
</body>
</html>