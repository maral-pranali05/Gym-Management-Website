<!DOCTYPE html>

<head>
    <style>
        * {
            background-color: #ffffff;
        }
        
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 120vh;
            margin: 0;
        }
        
        form {
            background: #ffffff;
            padding: 20px;
            border-radius: 10px;
            max-width: 400px;
            box-shadow: 0px 0px 10px rgb(138, 90, 2);
            width: 100%;
        }
        
        fieldset {
            border: none;
        }
        
        h2 {
            margin-bottom: 20px;
            text-align: center;
            color: #333;
        }
        
        i {
            font-style: normal;
            font-weight: bold;
            color: #555;
            font-size: 15px;
        }
        
        input {
            border: 0.5px solid;
        }
        
        input:focus {
            border: 5px solid orangered;
            outline: 1px solid orangered;
        }
        
     
        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 8px;
            margin: 2px 0 10px 0;
            border: 1px solid rgb(222, 216, 216);
            border-radius: 5px;
            font-size: 14px;
        }
        
        input[type="button"] {
            width: 100%;
            
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }
        
        input[type="button"] {
            background: #ee7715;
            color: white;
        }
        
        input[type="button"]:hover {
            background: #ee7715;
        }
        form p{
            display: flex;
            justify-content: center;
            margin-top: 5px;
        }
        form a{
            color:orangered;
        }
        
    </style>
    
        
    
    <script>
function login(){
        let name=document.frm1.name.value;
        let pass=document.frm1.pass.value;

        if(name!="omkar"){
            alert("plz enter a currect name");
        }
        else if(pass!=1266){
            alert("plz enter a currect password");
        }
        else{
            window.location.assign("membership.php");
    } 
    }
    </script>
</head>

<body>
    <form name="frm1">

        <fieldset>
            <h2>login</h2>
            <i> enter name: </i><br>
            <input type="text" id="name" placeholder="enter name" name="name"><br>
             <i> PASSWORD:</i>
            <input type="password" id="pass" placeholder="password" name="pass"><br>
            <input type="button" onclick="login();" value="LOGIN" id="submit"> <br><br>
            <p>Dont have an account?<a href="create.php">Register</p>

        </fieldset>
    </form>
</body>

</html>

