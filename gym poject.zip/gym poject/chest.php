<html>

<head>
    <title></title>
    
    <style>
        body {
    font-family: sans-serif;
    
    margin: 0px;
}

body h1 {
    padding-top: 30px;
    text-align: center;
    padding: 15px;
    margin-top: 0%;
    ;
}

.section {
    background-color: rgba(240,192,103);
    display: flex;
    justify-content: left;
    padding: 20px;
    width: 60%;
    /* margin: 10rem; */
    margin-bottom: 20px;
    margin-left:250px;
}

.section img {
    height: 250px;
}

.section h2 {
    margin: 0px;
    color: orangered;
}

.section p {
    color: #c0bdbd;
    margin-right: 7px;
}
    </style>
</head>

<body>
    <h1> CHEST WORKOUT</h1>

    <div class="section">
        <div class="text">
            <h2>Dumbell bench press</h2>
            <p>
                <h3>1.A dumbbell bench press is an upper body exercise where you lie on a weight bench, hold a dumbbell in each hand, and press the weights upwards, primarily targeting your chest muscles (pectoralis major), front shoulders (anterior deltoids),
                    and triceps brachii (back of the upper arm).
                </h3>
            </div>
            <img src="images/chest3.jpeg"
    
            </p>
    
        </div>
    
        <div class="section">
            <div class="text">
                <h2>Pushups</h2>
                <p>
                    <h3>Push-up exercise is a close chain kinetic exercise which improves the joint proprioception, joint stability and muscle co-activation around the shoulder joint. Push-ups activate a large number of muscles together, increasing the demand 
                        on the heart muscle and the respiratory rate.
                    </h3>
                </div>
                <img src="images/chest2.jpeg">
        
                </p>
        
            </div>
        
            <div class="section">
                <div class="text">
                    <h2>Cable crossover</h2>
                    <p>
                        <h3>Cable crossovers are effective for isolating and activating the inner chest, and developing the lower pecs. The cables provide constant tension throughout the range of motion Stand position: Stand with your feet slightly wider than shoulder-width
                            apart. Arm position: Hold your arms straight out to your sides. Handle position: Grab the handles and step forward.
                        </h3>
                    </div>
                    <img src="images/chest1.jpeg">
                    </p>
                </div>
            
                <div class="section">
                    <div class="text">
                        <h2>Chest flyes</h2>
                        <p>
                            <h3>he chest fly is a popular chest exercise used to develop the pectoral muscles. The exercise is performed on a bench with feet flat on the ground and knees bent at a 90-degree angle. People who are just starting their fitness journey can
                                use a lighter weight or perform the exercise with just their body weight.
                            </h3>
                    </div>
            
                    <img src="images/chest.jpeg">
                </div>
            </p>

        </div>
    </body>
    
    </html>
                            