<html>

<head>
    <title></title>
    <style>
         <style>
        body {
    font-family: sans-serif;
    
    margin: 0px;
}

body h1 {
    padding-top: 30px;
    text-align: center;
    padding: 15px;
    margin-top: 0%;
    ;
}

.section {
    background-color: rgba(240,192,103);
    display: flex;
    justify-content: left;
    padding: 20px;
    width: 60%;
    /* margin: 10rem; */
    margin-bottom: 20px;
    margin-left:250px;
}

.section img {
    height: 250px;
}

.section h2 {
    margin: 0px;
    color: orangered;
}

.section p {
    color: #c0bdbd;
    margin-right: 7px;
}
    </style>
    </style>
</head>

<body>
    <div class="gym">
        <h1> BACK WORKOUT</h1>
    </div>

    <div class="section">
        <div class="text">
            <h2>pendlay row</h2>
            <p>
                <h3>The pendlay row is a dead stop row that challenges the performer to row a barbell towards them from the floor while in a hip hinge. This movement typically uses an overhand, pronated grip and involves greater range of motion and more full
                    body strength than other row variations..
                </h3>
        </div>
        <img src="images/back4.jpeg">

        </p>

    </div>

    <div class="section">
        <div class="text">
            <h2>Pull ups</h2>
            <p>
                <h3>Engage your core and squeeze your shoulder blades together, then pull yourself up. Keep going until your chin is over the bar, then hold this position for a moment. Lower yourself, in a slow and controlled manner. Don't let yourself just
                    drop or you'll miss half the workout.</h3>

        </div>
        <img src="images/back.jpeg">

        </p>

    </div>

    <div class="section">
        <div class="text">
            <h2>seated row</h2>
            <p>
                <h3>Sit up tall with a slight bend through the knees. Tighten up the abs and low back to maintain a perpendicular angle to the floor with your torso. Roll the shoulders back and down. Squeeze them together as you row, thinking about pinching
                    a pencil in between them
                </h3>
        </div>
        <img src="images/back1.jpeg">
        </p>
    </div>

    <div class="section">
        <div class="text">
            <h2>Deadlift</h2>
            <p>
                <h3> Stand up straight, with your feet underneath the bar. The bar should cut across the middle of your feet and your shins should be almost touching the bar.
                </h3>
        </div>
        <img src="images/back4.jpeg">
    </div>

    </p>

    </div>
</body>

</html>
