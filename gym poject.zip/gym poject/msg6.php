<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Success</title>
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    text-align: center;
    padding: 100px;
}

.mem-success {
    background: white;
    padding: 40px;
    border-radius: 10px;
    display: inline-block;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
}

h2 {
    color: green;
}

.success-image {
    width: 150px;
    margin-top: 20px;
}

.back-btn {
    display: inline-block;
    margin-top: 15px;
    padding: 10px 15px;
    background: green;
    color: white;
    text-decoration: none;
    border-radius: 5px;
}
img
{
    height: 50px;
}
        </style>
</head>

    <body>
        
    
    <div class="mem-success">
        <h2>Membership Successfully!</h2>
        <div class="img">
        <img src="images/msg.png"></div>
        <div class="info">
            <h4>Your membership has Successfully placed!</h4>
            <h4><strong>Name:</strong><?php echo htmlspecialchars($_GET['name']);?></h4>
            <h4>JOIN DATE:<?php echo date("d-m-Y");?></h4>
            <h4>EXPERIY DATE:<?php echo date("d-m-Y",strtotime("+180 days"));?></h4>
            <h4>Thank you for Take Membership with Us!</h4>
        </div>

        <a href="index.php" class="back-btn">Thanku..</a>
    </div>
    

</body>
</html>