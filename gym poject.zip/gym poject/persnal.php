 <!DOCTYPE html>

<head>
    <title>page</title>
    <link rel="stylesheet" href="personal.css">
    <style>
        body
        {
            background-image: url("images/gym14.jpg");
            background-size:cover;
        }
        body h1 {
            font-size: 42px;
            margin-top: 7px;
            width: 350px;
            color: white;
            font-family: sans-serif;
            padding-left: 1px;
            padding-right: 1px;
            background-color: orangered;
            display: inline-block;
        }
        body h2 {
            font-size: 25px;
            font-family: sans-serif;
            height: 10px;
            font-family: sans-serif;
            margin-top: 0px;
            color: white;
        }
        
        body h3 {
            font-family: sans-serif;
            color: yellow;
            font-size: 30px;
            display: inline;
            justify-content: space-between;
            padding-left: 16px;
            margin-top: 25px;
        }
        
        .container {
            display: flex;
            padding-left: 170px;
        }
        
        .box1 {
            height: 150px;
            width: 300px;
            margin-top: 10px;
            padding-left: 5px;
        }
        
        .box2 {
            height: 150px;
            width: 490px;
            background-color: ;
            margin-top: 10px;
            padding-left: 5px;
        }
        
        .box3 {
            height: 150px;
            width: 130px;
            background-color:orangered;
            border-radius: 610cap;
            margin-left: 20px;
            padding-right: 20px;
        }
        
        .container h6 {
            font-family: italic;
            font-size: 35px;
            color:yellow;
            margin-left: 10px;
            margin-top: 40px;
            padding-left: 90px;
            padding-right: 100px;
        }
        
        .container h4 {
            font-family: italic;
            font-size: 15px;
            padding-left: 35px;
            color: white;
            margin-top: 10%;
            justify-content: center;
        }
        
        .container p {
            font-size: 45px;
            color: lightgoldenrodyellow;
            margin-top: 25px;
            padding-right: 30px;
            font-family: sans-serif;
            height: 10px;
            min-width: 10px;
        }
        
        .container h2 {
            font-size: 22px;
            color: rgb(249, 250, 243);
            font-family: sans-serif;
            margin-top: 50px;
            padding-left: 30px;
        }
        
        .container h5 {
            font-size: 15px;
            color: yellow;
            font-family: sans-serif;
            margin-top: 0px;
            padding-left: 30px;
            height: 2px;
        }
        
        .box2 {
            color: black;
            height: 45px;
            font-size: 15px;
            margin-top: 10px;
            padding-right: 20px;
        }
    </style>
</head>

<body align="center">

    <fieldset>
        <h1>PERSONAL <br>TRAINING
        </h1>
        <h2>OUR SERVICES</h2><br>


        <h2>WEIGHTS</h2>
        <h2>CARDIO</h2>

        <h2>ABS TRAINING</h2>

        <h2>CROSS FIT</h2>
        <h2>BOXING</h2>
        <br>

        <h3> LOSE WEIGHT </h3>

        <h3>GET IN SHAPE</h3><br><br>

        <h3>BUILD MUSCLE </h3>

        <h3>LOOK DIFFRENT</h3>

        <div class="container">
            <div class="box1">
                <h6>PERSONAL<br> TRAINER</h6>
            </div>
            <div class="box2">
            <p>SWAPNIL SIR</p>
                <h4>(CERTIFIED FITNESS TRAINER STATE CHAMPION IN POWER LIFTING) <br>MO NO:8080007033</h4>


            </div>
            <div class="box3">
                <h2> 52 DAYS
                </h2>
                <h5>CHALLENGE</h5>


            </div>

        </div>
        </fielset>
</body>

</html> 
