 <!DOCTYPE html> 

<body>
    <table align="center" text-align="center" border="1px" height="500" width="600" bordercolor="purple">
        <tr>
            <th style="background-color:orange">
                <h1>WORKOUT PLANS</h1>
            </th>
            <th style="background-color:orange">
                <h1>GO</h1>
            </th>
        </tr>
        <tr>
            <td>
                <h1 align="center">CHEST</h1>
            </td>
            <td>
                <h1 align="center"><button style="background-color:orangered;border-radius:15px;color:black;width:60px;height:35px;"><a href="chest.php" style="text-decoration: none;color: aliceblue;">GO</a></button>
                </h1>
            </td>
        </tr>
        <tr>
            <td>
                <h1 align="center">BACK</h1>
            </td>
            <td>
                <h1 align="center"><button style="background-color: orangered;border-radius:15px;width:60px;height:35px "><a href="back.php " style="text-decoration: none;color: aliceblue;">GO</a></button></h1>
            </td>
        </tr>
        <tr>
            <td>
                <h1 align="center ">LEGS</h1>
            </td>
            <td>
                <h1 align="center "><button style="background-color:orangered;border-radius:15px;width:60px;height:35px "><a href="leg.php "  style="text-decoration: none;color: aliceblue;">GO</a></button></h1>
            </td>
        </tr>
        <tr>
            <td>
                <h1 align="center ">BEICP</h1>
            </td>
            <td>
                <h1 align="center ">
                    <button style="background-color:orangered;border-radius:15px;width:60px;height:35px "><a href="baicep.php"  style="text-decoration: none;color: aliceblue;">GO</a></button></h1>
            </td>
        </tr>

    </table>


    </tr>

</table>

</html>

 
 <!-- <!DOCTYPE html>

<body style="padding-top:55px;">

    <table align="center" text-align="center" border="1px" height="500" width="600" bordercolor="orange">
        <tr>
            <th style="background-color:#ee7715">
                <h1>WORKOUT PLANS</h1>
            </th>
            <th style="background-color: #ee7715">
                <h1>GO</h1>
            </th>
        </tr>
        <tr>
            <td>
                <h1 align="center">CHEST</h1>
            </td>
            <td>
                <h1 align="center"><button style="background-color:orange;border-radius:15px;color:azure;width:60px;height:35px"><a href="gym2.html">GO</a></button>
                </h1>
            </td>
        </tr>
        <tr>
            <td>
                <h1 align="center">BACK</h1>
            </td>
            <td>
                <h1 align="center"><button style="background-color: orange;border-radius:15px;color:azure;width:60px;height:35px "><a href="gym3.html ">GO</a></button></h1>
            </td>
        </tr>
        <tr>
            <td>
                <h1 align="center ">LEGS</h1>
            </td>
            <td>
                <h1 align="center "><button style="background-color:orange;border-radius:15px;width:60px;height:35px "><a href="gym5.html ">GO</a></button></h1>
            </td>
        </tr>
        <tr>
            <td>
                <h1 align="center ">BEICP</h1>
            </td>
            <td>
                <h1 align="center ">
                    <button style="background-color:orange;border-radius:15px;width:60px;height:35px "><a href=" gym4.html ">GO</a></button></h1>
            </td>
        </tr>

    </table>

</body>

</html> -->