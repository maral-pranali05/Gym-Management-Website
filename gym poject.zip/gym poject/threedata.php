<?php

$servser ="localhost";
$username ="root";
$password ="";
$dbname ="memberships";

$con =mysqli_connect($servser,$username,$password,$dbname);

if(!$con)
{
    echo "not connected";
}


$name=$_POST['name'];
$city=$_POST['city'];
$mobile = mysqli_real_escape_string($con, $_POST['mobile']);


$sql= "INSERT INTO `three`(`name`, `city`, `mobile`) VALUES ('$name','$city','$mobile')";
$result = mysqli_query($con,$sql);
if($result)
{
    header("location:msg3.php?name=$name");
}
else
{
    echo "error";
}