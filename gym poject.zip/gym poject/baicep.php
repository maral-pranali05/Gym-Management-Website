<html>

<head>
    <title></title>
    <style>
         <style>
        body {
    font-family: sans-serif;
    
    margin: 0px;
}

body h1 {
    padding-top: 30px;
    text-align: center;
    padding: 15px;
    margin-top: 0%;
    ;
}

.section {
    background-color: rgba(240,192,103);
    display: flex;
    justify-content: left;
    padding: 20px;
    width: 60%;
    /* margin: 10rem; */
    margin-bottom: 20px;
    margin-left:250px;
}

.section img {
    height: 250px;
}

.section h2 {
    margin: 0px;
    color: orangered;
}

.section p {
    color: #c0bdbd;
    margin-right: 7px;
}
    </style>
    </style>
</head>

<body>
    <h1> BEICP WORKOUT</h1>

    <div class="section">
        <div class="text">
            <h2>Hammer curl</h2>
            <p>
                <h3>Hammer curls target the long head of the bicep as well as the brachialis (another muscle in the upper arm) and the brachioradialis (one of the key forearm muscles). The hammer curl is a relatively simple exercise that beginners can quickly
                    master.
                    </h3>
                </h3>
        </div>
        <img src="images/baicep1.jpeg">
        </p>

    </div>

    <div class="section">
        <div class="text">
            <h2>bicep curl</h2>
            <p>
                <h3>Specifically, the biceps curl works the muscles in the front of the upper arm. Nicole L. Campbell: To do a biceps curl with a dumbbell, hold a dumbbell with your palm facing upward. Slowly curl the weight up by bending your elbow, keeping
                    your elbow close to your body..</h3>

        </div>
        <img src="images/baicep.jpeg">

        </p>

    </div>

    <div class="section">
        <div class="text">
            <h2>barbell curl</h2>
            <p>
                <h3>The barbell curl targets your biceps brachii muscle as well as the brachialis, a muscle responsible for elbow flexion. With regular practice, barbell curls can help you build bigger biceps
                </h3>
        </div>
        <img src="images/baicep2.jpeg"></p>
    </div>
    <div class="section">
        <div class="text">
            <h2>Cable curl</h2>
            <p>
                <h3> What Do Cable Curls Work? Cable curls are an isolation exercise that works the biceps brachii, brachialis, the forearms, and the anterior deltoids. Are Cable Bicep Curls Effective? Cable bicep curls are an effective way to isolate and 
                    challenge the biceps.
                </h3>
        </div>

        <img src="images/baicep5.jpeg">
    </div>

    </p>
    </div>
</body>

</html>
