<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>

      table
      {
        width: 1300px;
      }  
      th
      {
        background-color: orange;
        color: black;
      }
      tr
      {
        height: 50px;
        text-align: center;
        
        
      }

    </style>
       
</head>
<body>
    <table border="11">
               
            <tr>
                
                <th><h1>food name</h1></th>
                <th><h1>calories</h1></th>
                <th><h1>protien</h1></th>
                <th><h1>carbs</h1></th>
                <th><h1>fat</h1></th>
            
            </tr>
        
            <tr>
                <td><h2>banana</h2></td>
                <td><h2>105</h2></td>
                <td><h2>0.1</h2></td>
                <td><h2>24</h2></td>
                <td><h2>0.2</h2></td>
            </tr>
            <tr>
                <td><h2>mung</h2></td>
                <td><h2>30</h2></td>
                <td><h2>24</h2></td>
                <td><h2>0.7</h2></td>
                <td><h2>0</h2></td>
            </tr>
            <tr>
                <td><h2>sattu powder</h2></td>
                <td><h2>202</h2></td>
                <td><h2>18</h2></td>
                <td><h2>22</h2></td>
                <td><h2>0.2</h2></td>
            </tr>
            <tr>
                <td><h2>whey protin</h2></td>
                <td><h2>103</h2></td>
                <td><h2>24</h2></td>
                <td><h2>24</h2></td>
                <td><h2>0.2</h2></td>
            </tr>
            <tr>
                <td><h2>eggs</h2></td>
                <td><h2>75</h2></td>
                <td><h2>6</h2></td>
                <td><h2>23</h2></td>
                <td><h2>5</h2></td>
            </tr>
            <tr>
                <td><h2>rajma </h2></td>
                <td><h2>105</h2></td>
                <td><h2>20</h2></td>
                <td><h2>23</h2></td>
                <td><h2>0.5</h2></td>
            </tr>
            <tr>
                <td><h2>chana</h2></td>
                <td><h2>103</h2></td>
                <td><h2>23</h2></td>
                <td><h2>24</h2></td>
                <td><h2>12</h2></td>
            </tr> <tr>
                <td><h2>milk</h2></td>
                <td><h2>200</h2></td>
                <td><h2>20</h2></td>
                <td><h2>20</h2></td>
                <td><h2>3.0</h2></td>
            </tr>
            <tr>
                <td><h2>oats</h2></td>
                <td><h2>105</h2></td>
                <td><h2>17</h2></td>
                <td><h2>24</h2></td>
                <td><h2>22</h2></td>
            </tr>
            <tr>
                <td><h2>pinnut butter</h2></td>
                <td><h2>300</h2></td>
                <td><h2>10</h2></td>
                <td><h2>15</h2></td>
                <td><h2>15</h2></td>
            </tr>
            <tr>
                <td><h2>chikun</h2></td>
                <td><h2>105</h2></td>
                <td><h2>20</h2></td>
                <td><h2>50</h2></td>
                <td><h2>0.2</h2></td>
            </tr>
           
           
           
           
    
    </table>
</body>
</html>