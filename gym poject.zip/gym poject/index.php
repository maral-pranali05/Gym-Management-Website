<html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <style>
        body {
            background-color: #090909;
            color: #1b1111;
            height: 30px;
        }
        /*navbar*/
        
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 50px;
            background: transparent;
            height: 50px;
            border: 2px solid white;
        }
        
        .logo {
            font-size: 30px;
            font-weight: bold;
            color: white;
            display: flex;
            align-items: center;
            gap: 10px;
            margin-top: 15px;
            padding-bottom: 15px;
            
        }
        
        .nav-links {
            /* list-style: none; */
            display: flex;
            gap: 20px;
        }
        
        .nav-links a:hover {
            color: #ffbe5c;
        }
        
        .nav-links li {
            display: inline;
        }
        
        .nav-links a {
            text-decoration: none;
            color: white;
            font-size: 18px;
            font-weight: bold;
            transition: 0.3s;
        }
        /**/
        
        body {
            background: #0c0c0c;
            color: #fff;
        }
        
        .hero-section {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 50px;
            height: 100vh;
            background: linear-gradient(to right, rgba(0, 0, 0, 0.9), rgba(0, 0, 0, 0.6));
        }
        
        .content {
            max-width: 50%;
        }
        /* benifit*/
        
        .benifit {
            background: black;
            height: 60px;
            padding-left: 570px;
            padding-top: 10px;
            font-weight: bold;
            border-top: 2px solid white;
            margin-bottom: 10px;
        }
        .benifit h2 {
            color: rgb(250, 241, 241);
        }
        
        .container {
            display: flex;
            justify-content: space-between;
        }
        
        .box {
            font-size: 15px;
            font-family: sans-serif;
            width: 400px;
            height: 300px;
            background: #333333;
            color: white;
            display: flex;
            padding: 5px;
            border: 0.1px solid white;
        }
        
        .section {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-evenly;
            background-color: #363534;
            padding: 15px;
            gap: 15px;
        }
        
        .box-info {
            height: 260px;
            width: 23%;
            background-color: #19191a;
            padding: 20px 0px 15px;
            margin-top: 5px;
            font-family: Arial, Helvetica, sans-serif;
            border-radius: 10px;
            box-shadow: 2px 2px 10px rgba(17, 17, 17, 1.1);
            text-align: center;
        }
        
        .box-content-info {
            margin-left: 1rem;
            margin-right: 1rem;
        }
        
        .box-info p {
            margin: 2px;
            padding: 2px;
            color: white;
            font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
            font-size: 1rem;
            line-height: 1.5;
        }
        
        .box-info:hover {
            background-color: #ffbe5c;
            color: #19191a;
        }
        
        .content {
            max-width: 50%;
        }
        
        h4 {
            color: #ffbe5c;
            font-size: 16px;
            text-transform: uppercase;
        }
        
        h1 {
            font-size: 50px;
            font-weight: bold;
        }
        /* h1 span {
            color: #ffffff;
        } */
        
        p {
            margin-top: 20px;
            font-size: 16px;
            line-height: 1.5;
        }
        /*instruction*/
        
        .instruction-section {
            background: url(images/img1.png) no-repeat center center/cover;
            padding: 90px 20px;
            text-align: center;
            position: relative;
            width: 100%;
            height: 500px;
        }
        
        .instruction-section .content {
            background-color: rgba(13, 12, 12, 0.7);
            max-width: 600px;
            border-radius: 10px;
        }
        
        .instruction-section h2 {
            font-size: 36px;
            margin-bottom: 10px;
            color: #f8ad3d;
            padding-right: 7px;
        }
        
        .instruction-section h3 {
            font-size: 18px;
            line-height: 1.6;
            margin-bottom: 15px;
            padding-right: 680px;
        }
        
        .instruction-section h4 {
            padding-right: 600px;
            color: #fecb7e;
            padding-bottom: 10px;
        }
        
        .section section {
            width: 97%;
            background-color: #ffffff79;
            text-align: center;
            padding: 5px;
            border-radius: 5px;
        }
        /* gynm workout diet mem per*/
        
        .container {
            background-color: #0c0c0c;
            border-radius: 10px;
            width: 100%;
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 30px;
            padding-bottom: 10px;
            text-align: center;
            padding-top: 0px;
        }
        
        .func {
            background: rgba(54, 52, 52, 0.39);
            padding: 9px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            width: 260px;
            margin-top: 22px;
            border: 3px solid transparent;
        }
        
        .func img {
            width: 220px;
            height: 250px;
            border-radius: 10px;
            transition: transform 0.3s ease, opacity 0.3s ease;
        }
        
        .func h2 {
            font-weight: bold;
            margin-top: 10px;
            padding-left: 400px;
        }
        
        .func:hover {
            border-color: rgb(227, 156, 24);
            transform: scale(1.05);
            box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.2);
        }
        
        .func img:hover {
            opacity: 0.8;
        }
        /*footer*/
        
        .about-contact {
            width: 100%;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            background-color: black;
            padding: 40px;
            color: white;
            border-radius: 5px;
            margin-bottom: 0px;
            /* flex-wrap: wrap; */
        }
        
        .about-box,
        .contact-box {
            width: 35%;
        }
        
        h2 {
            font-size: 1.8rem;
            margin-bottom: 15px;
            display: inline-block;
            padding-bottom: 5px;
        }
        
        .about-box p,
        .contact-box p {
            font-size: 1rem;
            line-height: 1.6;
            color: white;
        }
        
        .dots {
            margin-top: 20px;
        }
        
        .dots span {
            display: inline-block;
            width: 15px;
            height: 15px;
            background-color: rgb(251, 131, 2);
            color: white;
            border-radius: 50%;
            margin-right: 15px;
        }
        /* 2nd */
        
        .foot-content i {
            padding: 4px;
        }
        
        ul {
            margin-top: 2S0px;
            padding: 10px;
        }
        
        ul a {
            display: block;
            font-size: 15px;
            margin-top: 10px;
            color: #dddddd;
            text-decoration: none;
        }
        
        
        .copyright {
            height: 30px;
            background-color: rgba(13, 12, 12, 0.7);
            display: flex;
            justify-content: center;
            color: aliceblue;
            padding-top: 15px;
            padding-bottom: 20px;
        }
        html {
    scroll-behavior: smooth;
}
        </style>
</head>

<body>

    <nav class="navbar">
        <div class="logo">
            <h3 style="color: orange;">KINGS GYM</h3>
        </div>
        <ul class="nav-links">
            <li><a href="#">Home</a></li>
            <li><a href="login.php">Sign Up</a>
            </li>



        </ul>
    </nav>

    <div class="image">
        <img src="images/prnali.png">
    </div>



    <div class="benifit">
        <h2>BENIFITS Of GYM
            <h2>
    </div>

    <div class="section">
        <div class="box1 box-info">
            <div class="box-content-info">
                .1.improved physical health regular exercise helps improve cardiovascular health,strengthen muscels,enhance flexibility and maintain a healty weight,its also reduse the risk of chronic condition
                <br /> 2.mental health exercise releases endorphins,which can improve mood,reduse stress,and alleviate symtoms of anxiety and depressioney Protein is right choice for you.</p>
            </div>
        </div>


        <div class="box1 box-info">
            <div class="box-content-info">

                2.increased energy levels regular workout enhance stamina and overall enargy levels by improving bood flow and oxygen delivery throughout the body.<br> 3.social interaction and motivation the gym provides a space to meet like minded individuals
                build a community,and stay motivated by sharing goals and progress with oters.
            </div>
        </div>

        <div class="box1 box-info">
            <div class="box-content-info">
                3.better sleep quality consistent exercise promotes deeper and more restful sleep.also immune system physical activity can enhance your body's abilityto fight off illnesses
                <br /> 5.improve bone density weight bearing exercises at the gym helps strengthen bones and prevent conditions like osteoporosis,
            </div>
        </div>
        <div class="box1 box-info">
            <div class="box-content-info">
                6.increase self confidanse achiving fitness goals and feeling healthier boosts self esteem and body image<br> 7.weight management exercise helps burn calories and support weight management to stey fit in life Improved fitness: Increases
                strength, endurance, flexibility, and cardiovascular health. Mental health: Reduces stress, anxiety, and depression, boosting mood </div>
        </div>



        <section class="instruction-section">
            <div class="content">

                <h2>INSTRUCTIONS</h2>
            </div>
            <h3>Member should be use sanitizer in the gym</h3>
            <h4>1.anyone who is sick should avoid coming to the gym. <br>2.All weights should be placed on the rack after use.<br> 3.No one should place weights on the floor.<br> 4.cardio traning are ulternet 3 days in week.<br> 5.Shoes must be used for CARDIO
                (treadmill,cycle).
                 <br>6.Member can exercise in a ship in the morning or evening.<br> 7.Bring a track pant,t-shirt,sports,nepkin,water bottal,sanitizer while coming for exercise<br> 8.do not bring valuables(mobile,pocket etc.)while coming to the gym.gim
                if lost will not be responsible.</h4>

            <h3> Please exercise under the guidence of fitness trainers</h4>
        </section>
    </div>
    </div>



    <div class="container">

        <div class="func">
            <a href="table.php" target="_blank">
                <img src="images/workout.png">
            </a>

        </div>

        <div class="func">
            <a href="login.php" target="_blank">
                <img src="images/membership.png">
            </a>

        </div>

        <div class="func">
            <a href="dite.php" target="_blank">
                <img src="images/diet plan.png">
            </a>

        </div>
        <div class="func">
            <a href="persnal.php" target="_blank">
                <img src="images/personal tranning.png">
            </a>

</div>



<!-- <section class="about-contact"> -->
<section id="contact" class="about-contact">
    <div class="about-box">
        <h3>About us</h3>
        <p>A gym management system can offer you financial insights by producing reports and tracking your cash flow. It's essential that you know how much money is coming in and out of your business, whether that's monitoring multiple revenue streams
            or knowing the recurring revenue coming in every month.</p>
        <div class="dots">
            <span></span>
            <span></span>
        </div>
    </div>
    <div class="footer-section">
        <h3>Resources</h3>
        <ul>
            <a href="https://muffingroup.com/blog/gym-websites/">fitness Blog</a>

            <a href="https://ultimategymsolutions.com/">business</a>
        </ul>
    </div>

    <div class="contact-box">
        <h3>Contact Us</h3>
        <p>sr,no.18, lane no. 7, bhag-2,nasrapur bhor,<br>(pune) 412206</p>
        <p>📞 +91-9529738723</p>
        <p>✉️ info@gymnutrition.in</p>
    </div>
</section>

<div class="copyright ">
    Copyright 2025 web design all rights reserved.</div>
</div>
<script>
    document.querySelectorAll('nav a').forEach(link => {
        link.addEventListener('click', function(event) {
            event.preventDefault(); // Prevent default anchor click behavior
            const targetSection = document.querySelector(this.getAttribute('href'));
            if (targetSection) {
                targetSection.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
</script>
</body>
</html>