<html>

<head>
    <title></title>
    <style>
        
        body {
    font-family: sans-serif;
    
    margin: 0px;
}

body h1 {
    padding-top: 30px;
    text-align: center;
    padding: 15px;
    margin-top: 0%;
    ;
}

.section {
    background-color: rgba(240,192,103);
    display: flex;
    justify-content: left;
    padding: 20px;
    width: 60%;
    /* margin: 10rem; */
    margin-bottom: 20px;
    margin-left:250px;
}

.section img {
    height: 250px;
}

.section h2 {
    margin: 0px;
    color: orangered;
}

.section p {
    color: #c0bdbd;
    margin-right: 7px;
}
    </style>
    
</head>

<body>
    <h1 > LEGS WORKOUT</h1>

    <div class="section">
        <div class="text">
            <h2>Calf raise</h2>
            <p>
                <h3>Everyday movements such as running, walking, and jumping rely heavily on calf strength, which plays a significant role in overall performance and well-being. Calf raises, in particular, are a potent exercise for fitness improvement since
                    they focus on building strength and defining muscles in the lower legs..
                </h3>

        </div>
        <img src="images/legs1.jpeg">
        </p>

    </div>

    <div class="section">
        <div class="text">
            <h2>walking lungs</h2>
            <p>
                <h3>Walking lunges are a lower-body exercise that can help strengthen and stretch your glutes and hamstrings. They can also improve your balance and coordination. .</h3>

        </div>
        <img src="images/legs4.jpeg">

        </p>

    </div>

    <div class="section">
        <div class="text">
            <h2>squat</h2>
            <p>
                <h3>The squat is an effective exercise for strengthening the leg and back muscles. It can also improve core strength. The exercise requires practice to learn proper form that will reduce the risk of injury. There are many variations of squats,
                    each of which offers different benefits.
                </h3>
        </div>
        <img src="images/legs.jpeg"></p>
    </div>




    <div class="section">
        <div class="text">
            <h2>legg press</h2>
            <p>
                <h3> If you're looking for an allover body workout, then squats have the advantage over leg presses. But if balance is a problem, or you have shoulder or back pain, then leg presses may be a better choice.
                </h3>
        </div>

        <img src="images/legs2.jpeg">
    </div>
</p>

</div>
</body>

</html>
