<?php

$server ="localhost";
$username ="root";
$password ="";
$dbname ="login";

$con =mysqli_connect($server,$username,$password,$dbname);

if(!$con)
{
    echo "not connected";
}


$name=$_POST['name'];
$city=$_POST['city'];
$email=$_POST['email'];
$mobile = mysqli_real_escape_string($con, $_POST['mobile']);
$pass1=$_POST['pass1'];

$sql= "INSERT INTO `data`(`name`, `city`, `email`, `mobile`, `password`) VALUES ('$name','$city','$email','$mobile','$pass1')";
$result = mysqli_query($con,$sql);
if($result)
{
    header("location:membership.php");
}
else
{
    echo "error";
}















 
?>